Fictional example — not for submission.

This bundle accompanies the fictional Acme Metrics release artifacts. LICENSE and NOTICE are unmodified repository source files.
